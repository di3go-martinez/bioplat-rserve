# TODO: Add comment
# 
# Author: Matias
###############################################################################


#' Execute Kmeans function
#'
#' @param expressionProfileMatrix 
#' @param numberOfClustersToGenerate 
#'
#' @return 
#' @export
#'
#' @examples
doKmeans <- function(expressionProfileMatrix,number.of.cluster, max.iterations, algorithm.to.implement ){
	result<-kmeans (x = expressionProfileMatrix, centers = number.of.cluster, iter.max = max.iterations, algorithm = algorithm.to.implement)
	return (result$cluster) 
}

doClusterPAM <- function(expression.profile.matrix,number.of.clusters,metric.to.implement,is.standarized){
	library(cluster)
	groups <- number.of.clusters
	surv.event <- length(expression.profile.matrix[1,])
	resultPam <- pam(expression.profile.matrix,number.of.clusters, trace = 1, metric = metric.to.implement,stand = is.standarized)
	return (resultPam$cluster) 
}


doClusterKmeansHClust <- function(expression.profile.matrix,number.of.clusters, number.of.genes, method.to.implement){ #TODO: REMOVER number.of.genes!!!!
  number.of.genes <- dim(expression.profile.matrix)[2]
  #Distance matrix is calculated
  distanceMatrix<- dist(expression.profile.matrix, method = "euclidean")
  #This variable will store the initial centers. Each center is an array with the expression values mean for the samples in the hcluster
  hclustCenters <- matrix(nr=number.of.clusters,nc=number.of.genes)
  #Hierarchical clustering for calculating intial centers for doing kmeans
  hclustRes<- hclust(distanceMatrix, method=method.to.implement) 
  groupsHClust<- cutree(hclustRes, k=number.of.clusters) 
  
  for (j in 1:number.of.clusters){ 
    # j represents the cluster that will be processed
    #It gets all row numbers in the original expressionProfileMatrix that were assigned by hclust to cluster j
    ClusterJpositions<-which(groupsHClust %in% c(j)) 
    #It creates a matrix for storing the expression values for the samples in the cluster j
    clusterJExressionDataMatrix<- matrix(nr=length(ClusterJpositions),nc=number.of.genes)
    #It fullfills the expression matrix
    for(i in 1:length(ClusterJpositions)){
      clusterJExressionDataMatrix[i,]<-expression.profile.matrix[ClusterJpositions[i],]
    }
    #It calculates, for each gene,  the mean of the samples in the cluster j.
    centerForClusterJ<-colMeans(clusterJExressionDataMatrix)
    #It stores the vector as one center.
    hclustCenters[j,]<-centerForClusterJ
  }

	kmeansHclust <- kmeans(expression.profile.matrix, centers= hclustCenters, number.of.clusters,iter.max = 1000)

	return (kmeansHclust$cluster)
}

doHeatmap <- function(experiment) {
	library(RColorBrewer)
  	library(gplots)
	orderGroups <- order(experiment$groups)
	colSideColors <- displayColors(experiment$groups)
	p <- heatmap.2(t(experiment$expression[orderGroups,]),
			col=rev(redgreen(16)),Colv=FALSE, scale="none", labCol = NA, 
			ColSideColors = colSideColors,key=TRUE, symkey=FALSE, 
			density.info="histogram", trace="none", cexRow=0.7,dendrogram = "row",
			key.xlab = "Expression values \n (Red is upregulated, Green is downregulated)")
	legend("topright",legend=unique(experiment$groups),col=unique(colSideColors),
			lty= 1,lwd = 5,cex = 0.7,title = "Cluster colors",horiz = TRUE)
	return (p)
	
}


validateBiomarker <- function (expression.profile.matrix, surv.time, surv.event, groups){
	#Se carg? R6?
	new.experiment <- Experiment$new(expression.profile.matrix, as.character(c(1:295)), as.character(c(1:55)), surv.time, surv.event, groups)
	validation<-Validation$new(new.experiment, NULL)
	validation$do.validation()
	return (validation) 
}


doRemoveIncorrectSamplesAndGenes <- function (expression.profile.matrix, surv.time, surv.event) {
	
	experiment.cleaned<-ExperimentCleaned$new()
	samples.removed.expression.error = ""
	samples.removed.time.error = ""
	samples.removed.event.error = ""
	genes.removed = ""
	
	## Con esto eliminamos filas (samples) si son todos no numericos 
	all.nulls.samples <-  rowSums(is.finite(expression.profile.matrix)) != 0 # devuelve una matrix de verdadero y falso en los samples que tienen todos los valores incorrectos
	index.of.samples.removed <- which(all.nulls.samples %in% c(FALSE)) #devuelve los indice de los valores falsos 
	if(length(index.of.samples.removed) > 0){
	  
	  samples.removed.expression.error = row.names(expression.profile.matrix)[index.of.samples.removed]
		expression.profile.matrix <- expression.profile.matrix[all.nulls.samples,] #filtra los valores que son falsos deja los que son verdaderos 
		# removemos valores envontrados en surv.time y surv.event
		surv.time <- surv.time[-index.of.samples.removed]
		surv.event <- surv.event[-index.of.samples.removed] 
	}
	
	
	## Con esto removemos los valores invalidos de surv.time  
	all.nulls.surv.time <-  is.finite(surv.time)
	index.of.surv.time.removed <- which(all.nulls.surv.time %in% c(FALSE)) #devuelve los indice de los valores falsos 
	if(length(index.of.surv.time.removed) > 0){
		surv.time <- surv.time[all.nulls.surv.time]
		samples.removed.time.error = row.names(expression.profile.matrix)[index.of.surv.time.removed] 
		surv.event <- surv.event[-index.of.surv.time.removed] 
		expression.profile.matrix <- expression.profile.matrix[-index.of.surv.time.removed,] 
	}
	
	## Con esto removemos los valores invalidos de surv.event  
	all.nulls.surv.event <-  is.finite(surv.event)
	index.of.surv.event.removed <- which(all.nulls.surv.event %in% c(FALSE)) #devuelve los indice de los valores falsos 
	if(length(index.of.surv.event.removed) > 0) {
		surv.event <- surv.event[all.nulls.surv.event]
		samples.removed.event.error = row.names(expression.profile.matrix)[index.of.surv.event.removed]
		surv.time <- surv.time[-index.of.surv.event.removed] 
		expression.profile.matrix <- expression.profile.matrix[-index.of.surv.event.removed,] 
	}
	
	#Con esto eliminamos columnas (genes) si al menos hay un valor no numerico 
	all.nulls.genes <- colSums(is.finite(expression.profile.matrix)) == nrow(expression.profile.matrix) # devuelve una matrix de verdadero y falso en los samples que tienen todos los valores incorrectos
	index.of.genes.removed <- which(all.nulls.genes %in% c(FALSE)) #devuelve los indice de los valores falsos
	if(length(index.of.genes.removed) > 0) {
		genes.removed = colnames(expression.profile.matrix)[index.of.genes.removed]
		expression.profile.matrix<-expression.profile.matrix[,all.nulls.genes]
	}
	
	experiment.cleaned$expression.profile.matrix = expression.profile.matrix
	experiment.cleaned$surv.time = surv.time
	experiment.cleaned$surv.event = surv.event
	experiment.cleaned$samples.removed.expression.error = paste(samples.removed.expression.error, collapse = ",") 
	experiment.cleaned$samples.removed.time.error = paste(samples.removed.time.error, collapse = ",") 
	experiment.cleaned$samples.removed.event.error = paste(samples.removed.event.error, collapse = ",") 
	experiment.cleaned$genes.removed = paste(genes.removed, collapse = ",") 
	
	return (experiment.cleaned)
}




writeValidationToPDF <- function(gene.signature.name, time.vector, event.vector, groups.vector, number.of.clusters, output.path, x.lab="Time", y.lab="survival", print.surv.diff=TRUE, print.concordance.index=TRUE){
	
	library("survival")
	
	#It creates PDF 
	#grouping.fun.name<-name(grouping.fun)
	#file.name<-paste(gene.name, "_", grouping.fun.name, "_", number.of.clusters, "clusters")
	
	#pdf.file.name<-paste(gene.signature.name, "_", number.of.clusters, "clusters", ".pdf",sep="")
	#output.file.path=paste(output.folder, pdf.file.name, sep="")
	
	createAndOpenPDF(output.path)
	
	#It plots the kaplan Meier
	#groups<-grouping.FUN(expression.vector, number.of.clusters)
	
	n.groups <- length(unique(groups.vector))
	surv.fit<-survfit(formula = Surv(time.vector, event.vector) ~ groups.vector)
	plot(surv.fit,col=1:n.groups, xlab=x.lab, ylab=y.lab)
	
	theLegend<-c()
	
	#Survfit
	if (print.surv.diff){
		surv.diff.object<-getSurvDiff(time.vector, event.vector, groups.vector)
		theLegend<-append(theLegend, survDifftoString(surv.diff.object))
	}
	
	#coxph
	#if (print.coxph){
	#	multiomics.coxph.object<-multiomics.coxph.for.one.gene(gen=gene.name, time.vector, event.vector, expression.vector)
	#	theLegend<-append(theLegend, coxphToString(multiomics.coxph.object))
	#}
	
	
	if (print.concordance.index){
		concordance.index.object<-getConcordanceIndex(time.vector, event.vector, groups.vector)
		theLegend<-append(theLegend, concordnaceIndextoString(concordance.index.object))
	}
	
	title<-paste(gene.signature.name, "on TCGA")
	drawLegends(groups.vector, theLegend, title)
	
	dev.off()
	
}


drawLegends<-function(groups, theLegend, title){
	n.groups <- length(unique(groups))
	legend("bottomleft", legend=unique(groups),col=1:n.groups,text.col=1:n.groups,horiz=FALSE, bty='n')
	legend("top", legend=title, cex = 2, bty='n')
	legend("topright", legend=theLegend)
}


displayColors <- function(vect){
	ovect <- sort(vect)
	vrainbow <-  rainbow(length(unique(vect)))
	vcol <- c()
	# check if exist number cluster number 0 (vector are 1 index based) 
	if(ovect[1] == 0){
		for (i in 1:length(ovect)){
			vcol <- c(vcol,vrainbow[ovect[i]+1])
		}
	}else{
		for (i in 1:length(ovect)){
			vcol <- c(vcol,vrainbow[ovect[i]])
		}  
	}
	return (vcol)
}


doRemoveManualIncorrectSamples <- function (expression.profile.matrix,groups,surv.time, surv.event){
  experiment.cleaned<-ExperimentCleaned$new()
  samples.removed.expression.error = ""
  samples.removed.time.error = ""
  samples.removed.event.error = ""
  genes.removed = ""
  groups.cleaned = groups 
  
  
  ## Con esto removemos los valores invalidos de surv.time  
  all.nulls.surv.time <-  is.finite(surv.time)
  index.of.surv.time.removed <- which(all.nulls.surv.time %in% c(FALSE)) #devuelve los indice de los valores falsos 
  if(length(index.of.surv.time.removed) > 0){
    samples.removed.time.error = row.names(expression.profile.matrix)[index.of.surv.time.removed]
    surv.time <- surv.time[all.nulls.surv.time]
    surv.event <- surv.event[-index.of.surv.time.removed] 
    expression.profile.matrix <- expression.profile.matrix[-index.of.surv.time.removed,] 
    groups.cleaned <- groups.cleaned[-index.of.surv.time.removed]
  }
  
  ## Con esto removemos los valores invalidos de surv.event  
  all.nulls.surv.event <-  is.finite(surv.event)
  index.of.surv.event.removed <- which(all.nulls.surv.event %in% c(FALSE)) #devuelve los indice de los valores falsos 
  if(length(index.of.surv.event.removed) > 0) {
    samples.removed.event.error = row.names(expression.profile.matrix)[index.of.surv.event.removed]
    surv.event <- surv.event[all.nulls.surv.event]
    surv.time <- surv.time[-index.of.surv.event.removed] 
    expression.profile.matrix <- expression.profile.matrix[-index.of.surv.event.removed,] 
    groups.cleaned <- groups.cleaned[-index.of.surv.event.removed]
  }
  
  
  experiment.cleaned$expression.profile.matrix = expression.profile.matrix
  experiment.cleaned$surv.time = surv.time
  experiment.cleaned$surv.event = surv.event
  experiment.cleaned$groups = groups.cleaned
  experiment.cleaned$samples.removed.expression.error = paste(samples.removed.expression.error, collapse = ",") 
  experiment.cleaned$samples.removed.time.error = paste(samples.removed.time.error, collapse = ",") 
  experiment.cleaned$samples.removed.event.error = paste(samples.removed.event.error, collapse = ",") 
  experiment.cleaned$genes.removed = paste(genes.removed, collapse = ",") 
  return (experiment.cleaned)
  
}

