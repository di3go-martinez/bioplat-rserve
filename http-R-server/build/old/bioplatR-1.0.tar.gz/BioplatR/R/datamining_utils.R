# TODO: Add comment
# 
# Author: Matias
###############################################################################

#' @export
divideDatasetIntoTrainingAndTesting<- function (input.dataset.path, postfix.training, postfix.testing, samples.are.columns=TRUE){
	
	the.original.data.frame<-read.table(input.dataset.path, header=FALSE)

	
	if (samples.are.columns) nsamples<-ncol(the.original.data.frame)
	if (!samples.are.columns) nsamples<-nrow(the.original.data.frame)
	
	input.dataset.path.without.extension<-unlist(strsplit(input.dataset.path, ".csv"))[1]
	input.dataset.path.without.extension<-unlist(strsplit(input.dataset.path.without.extension, ".txt"))[1]
	
	output.path.training<-paste(input.dataset.path.without.extension, postfix.training, ".csv", sep="")
	output.path.testing<-paste(input.dataset.path.without.extension, postfix.testing, ".csv", sep="")
	
	all.samples.positions<-c(1:nsamples)
	samples.for.training.positions = sample(nsamples, nsamples/2)
	samples.for.testing.positions<-all.samples.positions[! all.samples.positions %in% samples.for.training.positions ]
	samples.for.training.positions <- samples.for.training.positions[samples.for.training.positions !=1]
	samples.for.testing.positions <- samples.for.testing.positions[samples.for.testing.positions !=1]
	
	if (samples.are.columns){
		column1<-data.frame(the.original.data.frame[,1])
		data.frame.for.training<-cbind(column1, the.original.data.frame[,samples.for.training.positions])
		data.frame.for.testing<-cbind(column1, the.original.data.frame[,samples.for.testing.positions])
	}
	else{
		row1<-the.original.data.frame[1,]
		data.frame.for.training<-cbind(row1, the.original.data.frame[samples.for.training.positions,])
		data.frame.for.testing<-cbind(row1, the.original.data.frame[samples.for.testing.positions,])
	}
	write.table(data.frame.for.training, output.path.training, col.names=FALSE, quote=FALSE, row.names=FALSE, sep="\t")
	write.table(data.frame.for.testing, output.path.testing, col.names=FALSE, quote=FALSE, row.names=FALSE, sep="\t")
	
}
