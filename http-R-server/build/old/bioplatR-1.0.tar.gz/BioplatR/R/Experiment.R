# TODO: Add comment
# 
# Author: Matias
###############################################################################


require("R6")

Experiment <- R6Class("Experiment",
		public = list(
				#numeric matrix. colnames are the sample names, rownames are the gene symbol.
				expression = NULL, 
				
				#character vector. Gene symbol list.
				genes = NULL,
				
				#character vector. Sample names list.
				sample.names = NULL,
				
				#character vector. Sample names list.
				n.samples = NULL,
				
				#number vector. Vector with surv time
				surv.time = NULL,
				
				#number vector. Vector with event
				surv.event = NULL,
				
				#number vector. Vector with groups
				groups = NULL,
				
				#number vector. Vector with groups
				n.groups = NULL,
				
				initialize = function(expression, genes, sample.names, surv.time, surv.event, groups) {
					self$expression <- expression
					self$genes <- genes
					self$sample.names <-sample.names
					self$surv.time <-surv.time
					self$surv.event <- surv.event
					self$groups <- groups
					self$n.groups <- length(unique(groups)) 
					self$n.samples <- length(sample.names)
				},
				
				setExpression = function(expression.matrix) { self$expression <- expression.matrix },
				
				setGenes = function(gene.list) { self$genes <- gene.list},
				
				setSampleNames = function(sample.names) { self$sample.names<- sample.names },
				
				setSurvTime = function(surv.time) { self$surv.time <- surv.time },
				
				setSurvEvent = function(surv.event) { self$surv.event <- surv.event },
				
				setGroups = function(groups) { self$groups <- groups },
				
				display = function() {
					#cat("Make = ", self$make,
					#		" Price = ", self$price, "\n")
				}
		)
)


