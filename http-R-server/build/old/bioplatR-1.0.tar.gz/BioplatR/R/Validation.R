# TODO: Add comment
# 
# Author: Matias
###############################################################################

#For adding a new metric you should have:
#	1-Add the atrribute on the class (Validationesult). Try to use numeric values and no objects to simplify the result
#	2-Set the value on Validation.R>>do.validation()
#	3-To access the new value just do validation$validation.result$newAttribute
#	4-Add the attribute to the Java class RValidationResult

require("R6")

Validation <- R6Class("Validation",
		public = list(
				#Experiment. It is an instance of the R6 class Experiment.
				experiment = NULL, 
				
				#An instance of the class R6  ValidationParameters.
				validation.parameters = NULL,
				
				validation.result=NULL,
				
				a=NULL,
				
				initialize = function(experiment, validation.parameters=NULL) {
					self$experiment <- experiment
					self$validation.parameters <- validation.parameters
					validation.result <- ValidationResult$new()
					validation.result$groups <- experiment$groups
				},
				
				setExperiment = function(experiment) { self$experiment <- experiment },
				
				setValidationParameters = function(validation.parameters ) { self$validation.parameters  <- validation.parameters},
				
				display = function() {
					#cat("Make = ", self$make,
					#		" Price = ", self$price, "\n")
				},

				do.validation = function(){
					#survdiff
					library(survival)
					a.surv.diff<-survdiff(formula = Surv(self$experiment$surv.time, self$experiment$surv.event) ~ self$experiment$groups) # 
					self$validation.result$survdiff.chisq<-a.surv.diff$chisq
					self$validation.result$survdiff.pvalue<-1 - pchisq(a.surv.diff$chisq, length(a.surv.diff$n) - 1)
					
					#concordance index
					library(survcomp)
					concordance.index<-concordance.index(self$experiment$groups, self$experiment$surv.time, self$experiment$surv.event, method="noether")
					self$validation.result$concordance.index.cindex<-concordance.index$c.index
					self$validation.result$concordance.index.pvalue<-concordance.index$p.value
					
					
					#roc curves
					library(survivalROC)
					roc <- survivalROC(Stime=self$experiment$surv.time, status=self$experiment$surv.event, marker=self$experiment$groups, predict.time = 365,span = 0.25*self$experiment$n.samples^(-0.20) )
					print(roc$predict.time)
					self$validation.result$roc.predict.time = roc$predict.time   
					self$validation.result$roc.survival = roc$Survival
					self$validation.result$roc.AUC = roc$AUC
					#self$roc$roc.image = NULL
					
					#Generacion de la imagen
					jpeg('roc_image.jpg',quality=90)
					plot(roc$FP, roc$TP, type="l", xlim=c(0,1), ylim=c(0,1),xlab=paste( "FP \n AUC = ",round(roc$AUC,3)), ylab="TP",main="Year = 1",col=c("red"))
					dev.off() 
					self$validation.result$roc.image = readBin('roc_image.jpg','raw',1024*1024)
					unlink('roc_image.jpg');
					
					# kaplan.meier.image
					jpeg('kaplan_meier_image.jpg',quality=90)
					surv.fit<-survfit(formula = Surv(self$experiment$surv.time, self$experiment$surv.event) ~ self$experiment$groups)
					plot(surv.fit, col= rainbow(self$experiment$n.groups), xlab="Time", ylab="Probability of Survival")
					legend("topright",legend=unique(self$experiment$groups),col=unique(displayColors(self$experiment$groups)),
							lty= 1,lwd = 5,cex = 0.7,title = "Cluster colors",horiz = TRUE)
					dev.off() 
					self$validation.result$kaplan.meier.image = readBin('kaplan_meier_image.jpg','raw',1024*1024)
					unlink('kaplan_meier_image.jpg')
					
					#heatmap image
					jpeg('heatmap_image.jpg',quality=90)
					doHeatmap(self$experiment)
					dev.off()
					self$validation.result$heatmap.image = readBin('heatmap_image.jpg','raw',1024*1024)
					unlink('heatmap_image.jpg')
					
				}
				
		)
)
