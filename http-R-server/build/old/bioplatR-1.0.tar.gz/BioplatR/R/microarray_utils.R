# TODO: Add comment
# 
# Author: Matias
###############################################################################


#It returns the data.matrix keeping the probe with highest variance. 
#   file.path: A text file with the expression data. File Format:
#				*First row should be the header containing the sample names
#				*In second row starts the expression data
#				*First column must contain the id for doing the aggregation 
colapseProbeIntoGeneKeepingTheOneWithHigherVariance <- function(file.path, first.expression.column, entrez.col.order){
	data.frame <- read.table(file.path, header = T, sep = "\t")
	print(nrow(data.frame))
	#resolver el mapeo de probe a geneId
	data.frame.with.variance.column<-addVarianceColumn(data.frame, first.expression.column)
	result<-removeRepeatedKeepingTheOneWithHighestVariance(data.frame.with.variance.column, entrez.col.order)
	return (result)
}



EnsembleToHGNC<-function(EnsembleIDs, organism="hsapiens_gene_ensembl"){
	
	gpl570 <- read.table("D:\\datosGenomica\\2015-01---collapse para Aldaz\\mappingProbeEntrez.txt", header = T, sep = "\t")
	expression<-read.table("D:\\datosGenomica\\2015-01---collapse para Aldaz\\GSE2658_series_matrixWithoutInfoAbove.txt", header = T, sep = "\t")
	merged<-merge(gpl570,expression,by.x=colnames(gpl570)[1], by.y=colnames(expression)[1], all.x=FALSE, all.y=FALSE)
	write.table(merged, "D:\\datosGenomica\\2015-01---collapse para Aldaz\\merged.txt", sep="\t",row.names=FALSE)
	
	
	
	require(biomaRt);
	affyids=mydat[,1]
	z<-EnsembleToHGNC(affyids)
	ensemble<-useMart("ensembl");
	hsp<-useDataset(mart=ensemble,dataset=organism);
	ids<-getBM(attributes=c("affy_hg_u133_plus_2", "ensembl_gene_id"), filters = "affy_hg_u133_plus_2",values=affyids, mart= hsp)
	
	#ensemble<-useMart("ensembl");
	#hsp<-useDataset(mart=ensemble,dataset=organism);
	#ids<-getBM(filters= "ensembl_gene_id",
	#		attributes= c("ensembl_gene_id","hgnc_id", "hgnc_symbol","description"),
	#		values= EnsembleIDs, mart= hsp);
	#return(ids);
	
	#select("hgu95av2.db", affyids, "ENTREZID", "PROBEID")
	#source("http://bioconductor.org/biocLite.R")
	#biocLite("hgu133plus2.db")
}


removeRepeatedKeepingTheOneWithHighestVariance<-function(data.frame, entrez.col.order){
	has.got.entrez.id<-!is.na(data.frame[,entrez.col.order])
	rows.without.entrez <- data.frame[(!has.got.entrez.id), ]
	rows.with.entrez <- data.frame[has.got.entrez.id, ]

	ordered.data.frame <- rows.with.entrez[order(rows.with.entrez[,entrez.col.order], -rows.with.entrez$variance), ] 
	data.frame.result<-ordered.data.frame[ !duplicated(ordered.data.frame[,entrez.col.order]), ]
	
	data.frame.result<-rbind(data.frame.result,rows.without.entrez) 
	
	return (data.frame.result[order(as.numeric(rownames(data.frame.result))),,drop=FALSE])
	
}

addVarianceColumn<-function(data.frame, first.expression.column){
	require(matrixStats) #install.packages(matrixStats)
	data.frame.expression.data<-data.frame[,first.expression.column:ncol(data.frame)]
	variances<-rowVars(as.matrix(data.frame.expression.data))
	data.frame$variance <- variances
	#write.table(as.numeric(data.frame.expression.data[1,]), "D:\\datosGenomica\\2015-01---collapse para Aldaz\\borrame.txt", sep="\t",row.names=FALSE)
	write.table(data.frame, "D:\\datosGenomica\\2015-01---collapse para Aldaz\\variance.txt", sep="\t",row.names=FALSE)
	
	return (data.frame)
}