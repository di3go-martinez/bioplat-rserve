# TODO: Add comment
# 
# Author: Matias
###############################################################################


require("R6")

ValidationParameters <- R6Class("ValidationParameters",
		public = list(
				#It is optional. If this parameter is set, then it will not be calculated the 
				clusters = NULL,
				
				#number vector. Vector with surv time
				surv.time = NULL,
				
				#number vector. Vector with event
				surv.event = NULL,
				
				initialize = function(expression, genes, sample.names, surv.time, surv.event, groups) {
					self$expression <- expression
					self$genes <- genes
					self$sample.names <-sample.names
					self$surv.time <-surv.time
					self$surv.event <- surv.event
				},
				
				setExpression = function(expression.matrix) { self$expression <- expression.matrix },
				
				setGenes = function(gene.list) { self$genes <- gene-list},
				
				setSampleNames = function(sample.names) { self$sample.names<- sample.names },
				
				setSurvTime = function(surv.time) { self$surv.time <- surv.time },
				
				setSurvEvent = function(surv.event) { self$surv.event <- surv.event },
				
				display = function() {
					#cat("Make = ", self$make,
					#		" Price = ", self$price, "\n")
				}
		
		)
)

