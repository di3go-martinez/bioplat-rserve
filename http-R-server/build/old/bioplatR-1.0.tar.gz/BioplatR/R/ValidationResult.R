# TODO: Add comment
# 
# Author: Matias
###############################################################################

#For adding a new metric you should have:
#	1-Add the atrribute on this class (Validationesult). Try to use numeric values and no objects to simplify the result
#	2-Set the value on Validation.R>>do.validation()
#	3-To access the new value just do validation$validation.result$newAttribute
#	4-Add the attribute to the Java class RValidationResult


require("R6")

ValidationResult <- R6Class("ValidationResult",
		public = list(
				groups = NULL,
				
				#It measures the correlation between expression and survival but it doesnt do groups 
				#It is not implemented yet. We should ask if it is possible to use it with many genes or if it is usefue just with one or two genes as we have in multiomics.
				coxph.score = NULL,
				coxph.pvalue = NULL,
				wald.test.score = NULL,
				wald.test.pvalue = NULL,
				
				#It does clusters and then evaluates the correlation with survdiff				
				survdiff.chisq=NULL,
				survdiff.pvalue=NULL,

				#kaplan meier image
				kaplan.meier.image = NULL,
				
				#It is a metrix representing how separated are the kaplan meier curves
				concordance.index.cindex = NULL,
				concordance.index.pvalue = NULL,
			
				
				#ROC 
				roc.predict.time = NULL,
				roc.survival = NULL,
				roc.AUC = NULL,
				roc.image = NULL,
				
				#Heatmap
				heatmap.image = NULL,
				
				#Samples removed with wrong values.
				samples.removed.expression.error = NULL,
				
				#Samples removed by wrong clinical data values 
				samples.removed.time.error = NULL,
				
				#Samples removed by wrong clinical data values 
				samples.removed.event.error = NULL,
				
				#Genes removed with wrong values  
				genes.removed = NULL, 
				
				initialize = function() {
				},
				
				#setSurvDiff = function(surv.diff) { self$surv.diff <- surv.diff },
				
				#setKaplanMeierImage = function(kaplan.meier.image) { self$kaplan.meier.image <-kaplan.meier.image},
				
				#setConcordanceIndex = function(concordance.index) { self$concordance.index<- concordance.index },
				
				#setGroups = function(groups) { self$groups <- groups },
				
				#setCoxph = function(coxph) { self$coxph <- coxph},
				
				#setRoc = function(roc) { self$roc <- roc},
				
				#setRocImage = function(roc.image) { self$coroc.imagexph <- roc.image},
				
				display = function() {
					#cat("Make = ", self$make,
					#		" Price = ", self$price, "\n")
				}
		
		)
)


