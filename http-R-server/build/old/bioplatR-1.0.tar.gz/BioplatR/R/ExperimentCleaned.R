require("R6")

ExperimentCleaned <- R6Class("ExperimentCleaned",
		public = list(
			expression.profile.matrix = NULL,
			surv.time = NULL,
			surv.event = NULL, 
			samples.removed.expression.error = NULL,
			samples.removed.time.error = NULL,
			samples.removed.event.error = NULL,
			genes.removed = NULL,
			groups = NULL
				
			)
		)