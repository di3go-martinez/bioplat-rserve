# TODO: Add comment
# 
# Author: Matias
###############################################################################


#It returns a data frame with 3 columns  "cancer_study_id" "name"            "description"
#Each of this studies has got many samples. But, TCGA offers differents sample subsets containing the samples with a particular feature. For example "Tumors with RNA data" contains the samples of this study that has got rna.
#TCGA calls CaseList to this subset.
get.studies<-function(){
	library('cgdsr')
	mycgds = CGDS("http://www.cbioportal.org/public-portal/")
	getCancerStudies(mycgds)
}

#Example cancer_study_id="brca_tcga"
#It returns all the subsets for this cancer study
#It returns a data.frame with 2 columns: case_list_id   case_list_name
get.subsets.for.study<-function(cancer_study_id){
	library('cgdsr')
	mycgds = CGDS("http://www.cbioportal.org/public-portal/")
	allStudies<-getCancerStudies(mycgds)
	subsets.for.study = getCaseLists(mycgds,cancer_study_id)[,1:2]
}



#It returns a dataframe with 2 columns:  genetic_profile_id                  genetic_profile_name
#It will filter the ones with rna
get.mrna.profiles.names<-function(cancer_study_id){
	library('cgdsr')
	mycgds = CGDS("http://www.cbioportal.org/public-portal/")
	mrna_geneticprofiles = getGeneticProfiles(mycgds,cancer_study_id)[,1:2]
	mrna_geneticprofiles[grepl("RNA", mrna_geneticprofiles$genetic_profile_name), ]
}

#Example case_list_id=brca_tcga_mrna     genetic_profile_id=brca_tcga_mrna_median_Zscores
#The samples are the columns and the rows are genes (it is trsposed to get the data with this format)
get.expression.data<-function(case_list_id, genetic_profile_id, gene.list){
	library('cgdsr')
	mycgds = CGDS("http://www.cbioportal.org/public-portal/")
	datosExpresion=getProfileData(mycgds,gene.list,genetic_profile_id,case_list_id)
	return (as.data.frame(t(datosExpresion)))
}

#It returns a vector with the clinical attributes that has this study
get.clinical.data.attributes<-function(case_list_id){
	library('cgdsr')
	mycgds = CGDS("http://www.cbioportal.org/public-portal/")
	myclinicaldata = getClinicalData(mycgds,case_list_id)
	clincal.data.attributes = colnames(myclinicaldata)
	
}


#It returns a vector with the clinical attributes that has this study
#The samples are the columns and the rows are clinicalData (it is trsposed to get the data with this format)
get.clinical.data<-function(case_list_id, attribute.names.vector){
	library('cgdsr')
	mycgds = CGDS("http://www.cbioportal.org/public-portal/")
	myclinicaldata = getClinicalData(mycgds,case_list_id)
	myclinicaldata.filtered = myclinicaldata[,attribute.names.vector]
	return (as.data.frame(t(myclinicaldata.filtered)))
	
}




